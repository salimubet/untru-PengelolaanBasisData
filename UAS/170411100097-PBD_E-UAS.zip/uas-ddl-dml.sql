-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Bulan Mei 2020 pada 04.08
-- Versi server: 10.4.10-MariaDB
-- Versi PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coba-uas`
--

DELIMITER $$
--
-- Prosedur
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `cetakDenda` (IN `idA` INT(5), IN `naA` VARCHAR(40))  NO SQL
SELECT detil_mengembalikan.NO_STRUK,
	anggota.ID_ANGGOTA,
	anggota.NAMA_ANGGOTA,
	buku.JUDUL_BUKU,
	mengembalikan.TGL_PINJAM,
	mengembalikan.TGL_KEMBALI,
	detil_mengembalikan.`DENDA`,
    CASE 
           WHEN DENDA=30000 THEN 'Hari ini, hari terakhir anda sebelum masuk blacklist'
           WHEN DENDA>30000 THEN 'Anda harus membayar denda dan mengembalikan buku dulu'
           WHEN DENDA=0 THEN 'Tanggungan Rp 0'
           ELSE 'Anda memiliki tanggungan'
        END AS 'KETERANGAN'

	
FROM detil_mengembalikan, mengembalikan, buku, anggota
WHERE detil_mengembalikan.`KODE_BUKU`=mengembalikan.`KODE_BUKU` AND
	mengembalikan.`KODE_BUKU`=buku.`KODE_BUKU` AND
	detil_mengembalikan.`ID_ANGGOTA`=mengembalikan.`ID_ANGGOTA` AND
	mengembalikan.`ID_ANGGOTA`=anggota.`ID_ANGGOTA` AND
    anggota.ID_ANGGOTA=idA AND anggota.NAMA_ANGGOTA=naA$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cetakStruk` (IN `idA` CHAR(5), IN `naA` VARCHAR(40))  NO SQL
SELECT detil_meminjam.NO_STRUK,
	anggota.ID_ANGGOTA,
	anggota.NAMA_ANGGOTA,
	buku.JUDUL_BUKU, buku.KODE_BUKU,
	meminjam.TGL_PINJAM,
	meminjam.TGL_KEMBALI
	
FROM detil_meminjam, meminjam, buku, anggota
WHERE detil_meminjam.`KODE_BUKU`=meminjam.`KODE_BUKU` AND
	meminjam.`KODE_BUKU`=buku.`KODE_BUKU` AND
	detil_meminjam.`ID_ANGGOTA`=meminjam.`ID_ANGGOTA` AND
	meminjam.`ID_ANGGOTA`=anggota.`ID_ANGGOTA` AND
    anggota.ID_ANGGOTA=idA AND anggota.NAMA_ANGGOTA=naA$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `ID_ANGGOTA` char(12) NOT NULL,
  `ID_PETUGAS` char(15) DEFAULT NULL,
  `NAMA_ANGGOTA` varchar(40) NOT NULL,
  `ALAMAT_ANGGOTA` varchar(100) DEFAULT NULL,
  `NO_TELP_ANGGOTA` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='tabel ini berisi identitas anggota perpustakaan';

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`ID_ANGGOTA`, `ID_PETUGAS`, `NAMA_ANGGOTA`, `ALAMAT_ANGGOTA`, `NO_TELP_ANGGOTA`) VALUES
('A-001', 'PT-001', 'Ahmad', 'Bangkalan', 0),
('A-002', 'PT-001', 'Boby', 'Lamongan', 0),
('A-003', 'PT-001', 'Candra', 'Bangkalan', 0),
('A-004', 'PT-002', 'Deni', 'Lamongan', 0),
('A-005', 'PT-001', 'Yudi', 'Surabaya', 0),
('A-006', 'PT-001', 'Fajar', 'Bangkalan', 0),
('A-007', 'PT-003', 'Toni', 'Surabaya', 0),
('A-008', 'PT-002', 'Zacky', 'Bangkalan', 0),
('A-009', 'PT-004', 'Rudi', 'Lamongan', 0),
('A-010', 'PT-006', 'Budi', 'Lamongan', 0),
('A-011', 'PT-009', 'Mahmud', 'Bangkalan', 0),
('A-012', 'PT-011', 'Zainal', 'Lamongan', 0),
('A-013', 'PT-003', 'Saiful', 'Bangkalan', 0),
('A-014', 'PT-004', 'Daniel', 'Surabaya', 0),
('A-015', 'PT-002', 'Rudi', 'Lamongan', 0),
('A-016', 'PT-001', 'Ahmad', 'Surabaya', 0),
('A-017', 'PT-002', 'Nur', 'Bangkalan', 0),
('A-018', 'PT-004', 'Nurdin', 'Bangkalan', 0),
('A-019', 'PT-002', 'Dedi', 'Malang', 0),
('A-020', 'PT-007', 'Yuda', 'Surabaya', 0),
('A-021', 'PT-010', 'Fahrul', 'Bangkalan', 0),
('A-022', 'PT-013', 'Tomi', 'Surabaya', 0),
('A-023', 'PT-009', 'Zuhri', 'Lamongan', 0),
('A-024', 'PT-015', 'Rusman', 'Bangkalan', 0),
('A-025', 'PT-014', 'Husni', 'Lamongan', 0),
('A-026', 'PT-010', 'Maimun', 'Bangkalan', 0),
('A-027', 'PT-013', 'Zaini', 'Surabaya', 0),
('A-028', 'PT-007', 'Khoirul', 'Bangkalan', 0),
('A-029', 'PT-014', 'Dani', 'Surabaya', 0),
('A-030', 'PT-002', 'Romi', 'Lamongan', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `KODE_BUKU` char(12) NOT NULL,
  `ID_PETUGAS` char(15) DEFAULT NULL,
  `JUDUL_BUKU` varchar(100) NOT NULL,
  `JUMLAH_BUKU` int(11) NOT NULL,
  `PENGARANG_BUKU` varchar(100) DEFAULT NULL,
  `PENERBIT_BUKU` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`KODE_BUKU`, `ID_PETUGAS`, `JUDUL_BUKU`, `JUMLAH_BUKU`, `PENGARANG_BUKU`, `PENERBIT_BUKU`) VALUES
('B-001', 'PT-008', 'Filosofi Keraton', 2, 'Agus', 'Gramedia'),
('B-002', 'PT-006', 'Asal-Usul Kejawen', 2, 'Agus', 'Gramedia'),
('B-003', 'PT-002', 'Mengenal Kebudayaan Tengger', 1, 'Agus', 'Gramedia'),
('B-004', 'PT-005', 'Kebudayaan Bali', 3, 'Ketut', 'Gramedia'),
('K-001', 'PT-006', 'Efek Begadang', 9, 'dr. Irianto', 'Gramedia'),
('K-002', 'PT-013', 'Kesehatan Jantung', 7, 'dr. Irianto', 'Gramedia'),
('K-003', 'PT-001', 'Mencegah Stroke', 9, 'dr. Irianto', 'Gramedia'),
('K-004', 'PT-004', 'Limpa dan Fungsinya', 1, 'dr. Irianto', 'Gramedia'),
('K-005', 'PT-001', 'Efek Blue Light pada Mata', 6, 'dr. Andi', 'Gramedia'),
('K-006', 'PT-008', 'Menjaga Kesehatan Mata', 2, 'dr. Andi', 'Gramedia'),
('K-007', 'PT-002', 'Arti Perbedaan Warna Mata', 1, 'dr. Andi', 'Gramedia'),
('S-001', 'PT-003', 'Manfaat Kulit Jeruk', 6, 'Dr. Hasan', 'Gramedia'),
('S-002', 'PT-013', 'Kimia Molekul', 2, 'Prof. Fadilah', 'Gramedia'),
('S-003', 'PT-007', 'Fisika Terapan', 5, 'Prof. Hanif', 'Gramedia'),
('T-001', 'PT-004', 'Listrik Dinamis', 2, 'Ir. Johan', 'Gramedia'),
('T-002', 'PT-002', 'Mesin Automata', 9, 'Khoiril dkk', 'Erlangga'),
('T-003', 'PT-010', 'Teori Mesin', 7, 'Khoiril dkk', 'Erlangga'),
('T-004', 'PT-013', 'Mesin dan Kehidupan', 5, 'Khoiril dkk', 'Erlangga'),
('T-005', 'PT-012', 'Pemrograman Mesin', 3, 'Khoiril dkk', 'Erlangga'),
('T-006', 'PT-001', 'Kiat Sukses Membuat Program', 7, 'Prof. Ayub', 'Gramedia'),
('T-007', 'PT-003', 'Coding untuk SMK', 8, 'Prof. Ayub', 'Erlangga'),
('T-008', 'PT-011', 'Dunia IT', 1, 'Prof. Ayub', 'Gramedia'),
('T-009', 'PT-002', 'AI Industri', 2, 'Prof. Ayub', 'Erlangga'),
('T-010', 'PT-008', 'Perangkat IT', 2, 'Prof. Ayub', 'Gramedia'),
('T-011', 'PT-004', 'Coding untuk Pemula', 7, 'Prof. Ayub', 'Gramedia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detil_meminjam`
--

CREATE TABLE `detil_meminjam` (
  `NO_STRUK` char(12) NOT NULL,
  `KODE_BUKU` char(12) NOT NULL,
  `ID_ANGGOTA` char(12) DEFAULT NULL,
  `JML_BUKU` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `detil_meminjam`
--

INSERT INTO `detil_meminjam` (`NO_STRUK`, `KODE_BUKU`, `ID_ANGGOTA`, `JML_BUKU`) VALUES
('X-001', 'B-002', 'A-004', 1),
('X-002', 'T-001', 'A-005', 2),
('X-003', 'K-002', 'A-003', 3),
('X-004', 'T-007', 'A-002', 2),
('X-005', 'T-005', 'A-006', 1),
('X-006', 'S-001', 'A-008', 1),
('X-007', 'K-001', 'A-012', 3),
('X-008', 'T-001', 'A-007', 2),
('X-009', 'T-006', 'A-013', 3),
('X-010', 'B-002', 'A-021', 2),
('X-011', 'T-009', 'A-017', 1),
('X-012', 'T-005', 'A-015', 3),
('X-013', 'T-003', 'A-001', 3),
('X-014', 'S-002', 'A-009', 2),
('X-015', 'K-003', 'A-027', 1),
('X-016', 'T-007', 'A-025', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detil_mengembalikan`
--

CREATE TABLE `detil_mengembalikan` (
  `NO_STRUK` char(12) NOT NULL,
  `KODE_BUKU` char(12) NOT NULL,
  `ID_ANGGOTA` char(12) DEFAULT NULL,
  `DENDA` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `detil_mengembalikan`
--

INSERT INTO `detil_mengembalikan` (`NO_STRUK`, `KODE_BUKU`, `ID_ANGGOTA`, `DENDA`) VALUES
('Y-001', 'B-002', 'A-004', 0),
('Y-002', 'T-001', 'A-005', 0),
('Y-003', 'K-002', 'A-003', 0),
('Y-004', 'T-007', 'A-002', 0),
('Y-005', 'T-005', 'A-006', 0),
('Y-006', 'S-001', 'A-008', 3000),
('Y-007', 'K-001', 'A-012', 7000),
('Y-008', 'T-001', 'A-007', 0),
('Y-009', 'T-006', 'A-013', 0),
('Y-010', 'B-002', 'A-021', 0),
('Y-011', 'T-009', 'A-017', 0),
('Y-012', 'T-005', 'A-015', 0),
('Y-013', 'T-003', 'A-001', 46000),
('Y-014', 'S-002', 'A-009', 0),
('Y-015', 'K-003', 'A-027', 33000),
('Y-016', 'T-007', 'A-025', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `meminjam`
--

CREATE TABLE `meminjam` (
  `KODE_BUKU` char(12) NOT NULL,
  `ID_ANGGOTA` char(12) NOT NULL,
  `TGL_PINJAM` date NOT NULL,
  `TGL_KEMBALI` date NOT NULL,
  `PETUGAS` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `meminjam`
--

INSERT INTO `meminjam` (`KODE_BUKU`, `ID_ANGGOTA`, `TGL_PINJAM`, `TGL_KEMBALI`, `PETUGAS`) VALUES
('B-002', 'A-004', '2019-01-04', '2019-01-05', 'Reza'),
('B-002', 'A-021', '2019-01-06', '2019-01-08', 'Moh. Faris'),
('K-001', 'A-012', '2019-01-05', '2019-01-07', 'Reza'),
('K-002', 'A-003', '2019-01-04', '2019-01-05', 'Reza'),
('K-003', 'A-027', '2019-01-06', '2019-01-08', 'Reza'),
('S-001', 'A-008', '2019-01-05', '2019-01-07', 'Moh. Faris'),
('S-002', 'A-009', '2019-01-06', '2019-01-08', 'Moh. Faris'),
('T-001', 'A-005', '2019-01-04', '2019-01-05', 'Moh. Faris'),
('T-001', 'A-007', '2019-01-05', '2019-01-07', 'Moh. Faris'),
('T-003', 'A-001', '2019-01-06', '2019-01-08', 'Reza'),
('T-005', 'A-006', '2019-01-04', '2019-01-05', 'Reza'),
('T-005', 'A-015', '2019-01-06', '2019-01-08', 'Moh. Faris'),
('T-006', 'A-013', '2019-01-06', '2019-01-08', 'Reza'),
('T-007', 'A-002', '2019-01-04', '2019-01-05', 'Moh. Faris'),
('T-007', 'A-025', '2019-01-06', '2019-01-08', 'Moh. Faris'),
('T-009', 'A-017', '2019-01-06', '2019-01-08', 'Reza');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mengembalikan`
--

CREATE TABLE `mengembalikan` (
  `KODE_BUKU` char(12) NOT NULL,
  `ID_ANGGOTA` char(12) NOT NULL,
  `TGL_PINJAM` date NOT NULL,
  `TGL_KEMBALI` date NOT NULL,
  `PETUGAS` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mengembalikan`
--

INSERT INTO `mengembalikan` (`KODE_BUKU`, `ID_ANGGOTA`, `TGL_PINJAM`, `TGL_KEMBALI`, `PETUGAS`) VALUES
('B-002', 'A-004', '2019-01-04', '2019-01-05', 'Reza'),
('B-002', 'A-021', '2019-01-06', '2019-01-08', 'Doddy'),
('K-001', 'A-012', '2019-01-05', '2019-01-19', 'Maimun'),
('K-002', 'A-003', '2019-01-04', '2019-01-05', 'Reza'),
('K-003', 'A-027', '2019-01-06', '2019-02-15', 'Doddy'),
('S-001', 'A-008', '2019-01-05', '2019-01-15', 'Budi'),
('S-002', 'A-009', '2019-01-06', '2019-01-08', 'Maimun'),
('T-001', 'A-005', '2019-01-04', '2019-01-05', 'Moh. Faris'),
('T-001', 'A-007', '2019-01-05', '2019-01-07', 'Azizah'),
('T-003', 'A-001', '2019-01-06', '2019-02-28', 'Budi'),
('T-005', 'A-006', '2019-01-04', '2019-01-05', 'Junaidi'),
('T-005', 'A-015', '2019-01-06', '2019-01-08', 'Rizky'),
('T-006', 'A-013', '2019-01-06', '2019-01-08', 'Azizah'),
('T-007', 'A-002', '2019-01-04', '2019-01-05', 'Rizky'),
('T-007', 'A-025', '2019-01-06', '2019-01-08', 'Azizah'),
('T-009', 'A-017', '2019-01-06', '2019-01-08', 'Budi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `petugas`
--

CREATE TABLE `petugas` (
  `ID_PETUGAS` char(15) NOT NULL,
  `NAMA_PETUGAS` varchar(40) NOT NULL,
  `PASSWORD` varchar(12) NOT NULL,
  `ALAMAT_PETUGAS` varchar(100) DEFAULT NULL,
  `NO_TELP_PETUGAS` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `petugas`
--

INSERT INTO `petugas` (`ID_PETUGAS`, `NAMA_PETUGAS`, `PASSWORD`, `ALAMAT_PETUGAS`, `NO_TELP_PETUGAS`) VALUES
('PT-001', 'Moh. Faris', 'peg001', 'Bangkalan', 819156291),
('PT-002', 'Reza', 'peg002', 'Bangkalan', 2147483647),
('PT-003', 'Rizky', 'peg002', 'Bangkalan', 2147483647),
('PT-004', 'Fitri', 'peg004', 'Surabaya', 2147483647),
('PT-005', 'Fatimah', 'peg005', 'Surabaya', 2147483647),
('PT-006', 'Arya', 'peg006', 'Surabaya', 2147483647),
('PT-007', 'Junaidi', 'peg007', 'Bangkalan', 0),
('PT-008', 'Azizah', 'peg008', 'Surabaya', 0),
('PT-009', 'Agus', 'peg009', 'Surabaya', 0),
('PT-010', 'Khoirul', 'peg010', 'Jombang', 0),
('PT-011', 'Rudi', 'peg011', 'Jombang', 0),
('PT-012', 'Doddy', 'peg012', 'Gresik', 0),
('PT-013', 'Budi', 'peg013', 'Malang', 0),
('PT-014', 'Syaiful', 'peg014', 'Jombang', 0),
('PT-015', 'Yusuf', 'peg015', 'Jombang', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`ID_ANGGOTA`),
  ADD KEY `FK_DILAYANI` (`ID_PETUGAS`);

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`KODE_BUKU`),
  ADD KEY `FK_DIDATA` (`ID_PETUGAS`);

--
-- Indeks untuk tabel `detil_meminjam`
--
ALTER TABLE `detil_meminjam`
  ADD PRIMARY KEY (`NO_STRUK`,`KODE_BUKU`),
  ADD KEY `FK_RELATIONSHIP_7` (`KODE_BUKU`,`ID_ANGGOTA`);

--
-- Indeks untuk tabel `detil_mengembalikan`
--
ALTER TABLE `detil_mengembalikan`
  ADD PRIMARY KEY (`NO_STRUK`,`KODE_BUKU`),
  ADD KEY `FK_DETIL_MENGEMBALIKAN` (`KODE_BUKU`,`ID_ANGGOTA`);

--
-- Indeks untuk tabel `meminjam`
--
ALTER TABLE `meminjam`
  ADD PRIMARY KEY (`KODE_BUKU`,`ID_ANGGOTA`),
  ADD KEY `FK_MEMINJAM2` (`ID_ANGGOTA`);

--
-- Indeks untuk tabel `mengembalikan`
--
ALTER TABLE `mengembalikan`
  ADD PRIMARY KEY (`KODE_BUKU`,`ID_ANGGOTA`),
  ADD KEY `FK_MENGEMBALIKAN2` (`ID_ANGGOTA`);

--
-- Indeks untuk tabel `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`ID_PETUGAS`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD CONSTRAINT `FK_DILAYANI` FOREIGN KEY (`ID_PETUGAS`) REFERENCES `petugas` (`ID_PETUGAS`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `FK_DIDATA` FOREIGN KEY (`ID_PETUGAS`) REFERENCES `petugas` (`ID_PETUGAS`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `detil_meminjam`
--
ALTER TABLE `detil_meminjam`
  ADD CONSTRAINT `FK_RELATIONSHIP_7` FOREIGN KEY (`KODE_BUKU`,`ID_ANGGOTA`) REFERENCES `meminjam` (`KODE_BUKU`, `ID_ANGGOTA`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `detil_mengembalikan`
--
ALTER TABLE `detil_mengembalikan`
  ADD CONSTRAINT `FK_DETIL_MENGEMBALIKAN` FOREIGN KEY (`KODE_BUKU`,`ID_ANGGOTA`) REFERENCES `mengembalikan` (`KODE_BUKU`, `ID_ANGGOTA`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `meminjam`
--
ALTER TABLE `meminjam`
  ADD CONSTRAINT `FK_MEMINJAM` FOREIGN KEY (`KODE_BUKU`) REFERENCES `buku` (`KODE_BUKU`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_MEMINJAM2` FOREIGN KEY (`ID_ANGGOTA`) REFERENCES `anggota` (`ID_ANGGOTA`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `mengembalikan`
--
ALTER TABLE `mengembalikan`
  ADD CONSTRAINT `FK_MENGEMBALIKAN` FOREIGN KEY (`KODE_BUKU`) REFERENCES `buku` (`KODE_BUKU`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_MENGEMBALIKAN2` FOREIGN KEY (`ID_ANGGOTA`) REFERENCES `anggota` (`ID_ANGGOTA`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
